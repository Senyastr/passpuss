class MyPussy{
    int m;
    
}