//
//  Generated file. Do not edit.
//

#import "GeneratedPluginRegistrant.h"

#if __has_include(<flutter_android/FlutterAndroidPlugin.h>)
#import <flutter_android/FlutterAndroidPlugin.h>
#else
@import flutter_android;
#endif

#if __has_include(<flutter_sqlcipher/FlutterSQLCipherPlugin.h>)
#import <flutter_sqlcipher/FlutterSQLCipherPlugin.h>
#else
@import flutter_sqlcipher;
#endif

#if __has_include(<path_provider/FLTPathProviderPlugin.h>)
#import <path_provider/FLTPathProviderPlugin.h>
#else
@import path_provider;
#endif

@implementation GeneratedPluginRegistrant

+ (void)registerWithRegistry:(NSObject<FlutterPluginRegistry>*)registry {
  [FlutterAndroidPlugin registerWithRegistrar:[registry registrarForPlugin:@"FlutterAndroidPlugin"]];
  [FlutterSQLCipherPlugin registerWithRegistrar:[registry registrarForPlugin:@"FlutterSQLCipherPlugin"]];
  [FLTPathProviderPlugin registerWithRegistrar:[registry registrarForPlugin:@"FLTPathProviderPlugin"]];
}

@end
